using KadGen.Functional.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FuncitonalSamples.Test
{
    [TestClass]
    public class TestCommonClasses
    {
        [TestMethod]
        public void Can_create_success_rich_data()
        {
            Assert.IsNotNull(RichData.Success(42));
            Assert.IsNotNull(RichData<int>.Success(42));
        }

        [TestMethod]
        public void Can_create_error_rich_data()
        {
            Assert.IsNotNull(RichData<int>.Error(
                new ExceptionFailOutcome(new DivideByZeroException())));
        }

        [TestMethod]
        public void If_we_kill_non_generic_RichData()
        {
            Assert.IsNotNull(RichData.Success(42));
            Assert.IsNotNull(RichData.Error(
                new ExceptionFailOutcome(new DivideByZeroException())));

            Assert.IsNotNull(RichData<VoidType>.Success(default));
            Assert.IsNotNull(RichData<VoidType>.Error(
                new ExceptionFailOutcome(new DivideByZeroException())));
        }
    }
}
