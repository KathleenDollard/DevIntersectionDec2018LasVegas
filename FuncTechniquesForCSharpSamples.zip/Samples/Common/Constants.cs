﻿namespace KadGen.Functional.Common
{
    public struct Constants
    {
        public static readonly ResultStatus Success = ResultStatus.Success;
        public static readonly ResultStatus Fail = ResultStatus.Fail;
        public static readonly ResultStatus PartialSuccess = ResultStatus.PartialSuccess;

        public static readonly VoidType VoidData = new VoidType();

    }
}
