﻿using static KadGen.Functional.Common.Constants;

namespace KadGen.Functional.Common
{
    public abstract class BaseRichData
    {
        protected BaseRichData(Outcome outcome) : this(outcome.ResultStatus)
        => Outcome = outcome;

        protected BaseRichData(ResultStatus resultStatus)
        => ResultStatus = resultStatus;

        public ResultStatus ResultStatus { get; }
        public Outcome Outcome { get; }

        public static TRichData GetErrorRichData<TRichData>(ErrorOutcome errorOutcome)
        => ReflectionHelpers.CreateInstanceWithPublicOrNonPublicConstructor<TRichData>(errorOutcome);
    }

    public class RichData : RichData<VoidType>
    {
        private RichData(Outcome outcome)
        : base(outcome, VoidData) { }

        private RichData(ResultStatus resultStatus)
        : base(resultStatus, VoidData) { }

        public static RichData Success()
        => new RichData(Constants.Success);

        // This allows best semantics at point of usage. 
        public static RichData<T> Success<T>(T data )
        => new RichData<T>(Constants.Success, data);


        public static RichData Warning(WarningOutcome warningOutcome)
        => new RichData(warningOutcome);

        public static RichData Info(WarningOutcome warningOutcome)
        => new RichData(warningOutcome);

        public static RichData Error(ErrorOutcome errorOutcome)
        => new RichData(errorOutcome);
    }

    public class RichData<TData> : BaseRichData
    {
        internal RichData(ResultStatus resultStatus, TData data) : base(resultStatus)
        => Data = data;

        internal RichData(Outcome outcome, TData data) : base(outcome)
        => Data = data;

        public TData Data { get; }

        // This is there in case someone chooses to include the generic. 
        public static RichData<TData> Success(TData data)
        => new RichData<TData>(Constants.Success, data);

        public static RichData<TData> Warning(Outcome warningOutcome, TData data)
        => new RichData<TData>( warningOutcome, data);

        public static RichData<TData> Info(Outcome infoOutcome, TData data)
        => new RichData<TData>( infoOutcome, data);

        public static RichData<TData> Error(Outcome errorOutcome)
        => new RichData<TData>( errorOutcome, default);

        public static implicit operator RichData<TData>(ErrorOutcome errorOutcome)
        => new RichData<TData>( errorOutcome, default);

        public static implicit operator RichData<TData>((WarningOutcome WarningOutcome, TData Data) tuple)
         => new RichData<TData>(tuple.WarningOutcome, tuple.Data);

        public static implicit operator RichData<TData>((InfoOutcome InfoOutcome, TData Data) tuple)
         => new RichData<TData>(tuple.InfoOutcome, tuple.Data);

        public static implicit operator RichData<TData>(TData data)
        => new RichData<TData>(Constants.Success,  data);
    }

    public class RichPassage<T> : RichData<T>// I hate this name
    {
        internal RichPassage(ResultStatus resultStatus, T data, object input)
        : base(resultStatus, data) => Input = input;

        internal RichPassage(Outcome outcome, T data, object input)
        : base(outcome, data) => Input = input;

        public object Input { get; }
    }
}
