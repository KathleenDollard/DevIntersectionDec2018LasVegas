﻿using System;

namespace KadGen.Functional.Common
{
    // This is included for comparison with the ResultStatus struct. 
    // Simpler, but less powerful
    public enum OutcomeEnumDoNotUse
    {
        Fail = 0,
        PartialSuccess = 1,
        Success = 2
    }

    public struct ResultStatus : IEquatable<ResultStatus>, IComparable<ResultStatus>
    // can be a class if you want to extend
    {
        public int Value { get; }

        private ResultStatus(int value)
            => Value = value;

        public static ResultStatus Fail = new ResultStatus(0);
        public static ResultStatus PartialSuccess = new ResultStatus(1);
        public static ResultStatus Success = new ResultStatus(2);

        #region overloaded operators
        // Almost everything uses Comparison!
        // I choose semantics that an ResultStatus can be less than success or more than fail
        // That this happens to be the numeric order, is an implementation detail. You could 
        // use a switch for other rules.
        public static int Comparison(ResultStatus x1, ResultStatus x2)
        => (x1.Value < x2.Value)
            ? -1
            : (x1.Value == x2.Value)
               ? 0
               : 1;

        public static bool operator ==(ResultStatus x1, ResultStatus x2)
        => Comparison(x1, x2) == 0;

        public static bool operator !=(ResultStatus x1, ResultStatus x2)
        => Comparison(x1, x2) != 0;

        public override bool Equals(object obj)
        => (obj is ResultStatus resultStatus)
            ? Comparison(this, resultStatus) == 0
            : false;

        public bool Equals(ResultStatus other) => this == other;

        // This impleemntationis just what the generate GetHashCode fixer 
        // producedand uses a prime, which is good for hashes
        public override int GetHashCode()
        => -1937169414 + Value.GetHashCode();

        public static bool operator <(ResultStatus x1, ResultStatus x2) 
        => Comparison(x1, x2) < 0;

        public static bool operator >(ResultStatus x1, ResultStatus x2)
        => Comparison(x1, x2) > 0;

        public static bool operator <=(ResultStatus x1, ResultStatus x2)
       => Comparison(x1, x2) <= 0;

        public static bool operator >=(ResultStatus x1, ResultStatus x2)
        => Comparison(x1, x2) >= 0;

        public int CompareTo(ResultStatus other)
        => Comparison(this, other);

        // For comparison with ternary
        public static int Comparison2(ResultStatus x1, ResultStatus x2)
        {
            if (x1.Value < x2.Value)
            {
                return -1;
            }
            else if (x1.Value == x2.Value)
            {
                return 0;
            }
            else if (x1.Value > x2.Value)
            {
                return 1;
            }
            return 0;
        }

        #endregion
    }
}
