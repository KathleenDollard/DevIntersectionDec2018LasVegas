﻿using System;

namespace KadGen.Functional.Common
{
    public class VoidType
    {}
}
