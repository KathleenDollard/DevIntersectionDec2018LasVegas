Thanks for coming to my talk! 

This code is demo code, so there's no warranty of any kind. 
None. Nada. Sample code. Seriously, this is to convey ideas
so no warranty of any kind. 

There's also not really anything to run yet. Just code to explore. 
If you were at the talk, the PlaySpace files will be the most 
interesting, along with RichData. If you weren't at the talk, 
this isn't likely to make sense without context. 

But please explore and experiment with it.

The material in my references slide is really awesome, please check
those resources out. 

This is a moment of a work in progress. I plan to do more work 
on this to create an architecture flowing this information structure
through. My next step will be have the input and return value carried
in the same structure - so when you arrive at the end you can know
where you began. 

The structures are complex - that's because the priority is simple usage. 

Check back at the repository home page to see notes on where evolved 
versions of this approach are located. 

Enjoy!