﻿using System;
using System.Linq;

namespace KadGen.Functional.Samples
{
    public class InsideOutProgramming
    {
        // The code in the talk follows, and some more sophisticated 
        // was of doing this. 
        public int FooStarting(int x, int y)
        {
            try
            {
                return Using<dbContext>(new CTDbContext(Utilities.GetConnString()),
                            d => d.Courses.Count() + x + y);
            }
            catch
            {
                return -1; // Don't do this, it's a stupid sample
            }
        }

        public int Using<T>(Func<T> getDisposable, Func<T, int> getResult)
            where T : IDisposable
        {
            using (var disposable = getDisposable())
            {
                return getResult();
            }

        }

        // The code at the end of the talk had a bug, I had neglected
        // the return statement. It is fixed here. 
        public int Foo(int x, int y)
        {
            try
            {
                return Using(
                    () => new CTDbContext(Utilities.GetConnString()),
                    d => d.Courses.Count() + x + y);
            }
            catch
            {
                return -1; // Don't do this, it's a stupid sample
            }
        }

        public TReturn Using<TReturn, TDisposable>(
            Func<TDisposable> getDisposable,
            Func<TDisposable, TReturn> operation)
            where TDisposable : IDisposable
        {
            using (TDisposable disposable = getDisposable())
            {
                return operation(disposable);
            }
        }



        // This is the demo I cut short. 
        public int Foo2(int x, int y)
         => Handling.WithDemoHandling(
                () => Disposable.Using(
                    () => new CTDbContext(Utilities.GetConnString()),
                    disp => disp.Courses.Count() + x + y));

        // Here is the same demo returning a data result via implicit operator conversion
        public RichData<int> Foo3(int x, int y)
            => Handling.WithCommonHandling(
                () => Disposable.Using(
                    () => new CTDbContext(Utilities.GetConnString()),
                    disp => (RichData<int>)(disp.Courses.Count() + x + y)));
    }

    // Further adjust this to your specific situation to clean it up further. For example, 
    // if you always create the same context, you could combine the Using and WithCommonHandling 
    // methods.

}
